package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@SpringBootTest
class DemoApplicationTests {
	Calculator underTest=new Calculator();
	@Test
	void itshouldaddnumbers() {
		int asserts=underTest.add(2,30);
		int result=50;
		assertThat(asserts).isEqualTo(50);
	}
class  	Calculator{
		int add(int a,int b){
			return a+b;
		}
}
}
