package com.example.demo.student;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import javax.persistence.GeneratedValue;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
class StudentRepositoryTest {
@Autowired
    private StudentRepository underTest;

    @AfterEach
    void tearDown() {
        underTest.deleteAll();
    }

    @Test
    void itShouldCheckIfSelectExistsEmail() {
String email="manoj.kota2k@gmail.com";
        Student student=new Student("manoj",email, Gender.MALE);
        underTest.save(student);
      boolean expected=  underTest.selectExistsEmail(email);
      assertThat(expected).isTrue();
    }
    @Test
    void itShouldCheckIfSelectEmailDoesNotExist() {
        String email="manoj.kota2k@gmail.com";
        boolean expected=  underTest.selectExistsEmail(email);
        assertThat(expected).isFalse();
    }
}